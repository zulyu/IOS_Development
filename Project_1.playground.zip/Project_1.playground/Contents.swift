import UIKit
import Foundation

// * * * * * SECTION A: 1.1 Is my number prime?

// PSEUDO-CODE
/* 1. Create a function checkForPrimeNum that accepts an integer called possiblePrimeNumber.
   2. Check if possiblePrimeNumber is less than or equal to 1:
    --> If true, return false because prime numbers must be greater than 1.
   3. Loop through all numbers starting from 2 up to the square root of possiblePrimeNumber:
    --> If possiblePrimeNumber is divisible by any of these numbers, return false (the number is composite).
   4. If no divisors are found in the loop, return true because the number is prime. */

// ! CHECK FOR PRIME NUM FUNCTION
    // --> checks if a given number is prime
    // - parameter possiblePrimeNumber: an int that will be checked if it's prime or not
    // - returns: a boolean indicating whether the number is prime (true) or not (false)

func checkForPrimeNum(_ possiblePrimeNumber: Int) -> Bool {
    if possiblePrimeNumber <= 1 { return false }  // any number less than or equal to 1 is not prime
    
    for divisor in 2...Int(sqrt(Double(possiblePrimeNumber))) { // check divisibility (start from 2 and end at the square root of the number being checked)
        if possiblePrimeNumber % divisor == 0 { // no remainders --> not a prime number
            return false
        }
    }
    return true
}

// testing
let num1 = 17
let num2 = 14

print(checkForPrimeNum(num1)) // prints true
print(checkForPrimeNum(num2)) // prints false

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// * * * * * SECTION B: 1.3 Is my password correct?

// PSEUDO-CODE
/* 1. Define a function correctPassword that accepts a string userPassword.
   2. Create two closures:
    --> hasUppercaseLetter checks if userPassword contains at least one uppercase letter.
    --> hasSpecialChar checks if userPassword contains at least one special character.
   3. Check if:
    --> The length of userPassword is greater than or equal to 5.
    --> hasUppercaseLetter returns true.
    --> hasSpecialChar returns true.
   4. Return true if all conditions are satisfied, otherwise return false.*/

// ! HAS UPPERCASE LETTER
// --> a closure to check if the string contains at least one uppercase letter
let hasUppercaseLetter: (String) -> Bool = { userPassword in // checks for an uppercase letter in the password
    return userPassword.rangeOfCharacter(from: .uppercaseLetters) != nil // // returns true if an uppercase letter is found & false otherwise
}

// ! HAS SPECIAL CHAR
// --> a closure to check if the string contains at least one uppercase letter
let hasSpecialChar: (String) -> Bool = { userPassword in // checks for a special character in the password
    let specialCharacters = "!@#$%^&*" // from problem task description
    return userPassword.rangeOfCharacter(from: CharacterSet(charactersIn: specialCharacters)) != nil // returns true if any special character is found & false otherwise
}

// ! CORRECT PASSWORD FUNCTION
    // --> checks whether a given password meets the 3 conditions
    // - parameter userPassword: a string representing the user-entered password
    // - returns: a boolean indicating if the password is secure (true) or not (false)

func correctPassword(_ userPassword: String) -> Bool {
    return userPassword.count >= 5 && hasUppercaseLetter(userPassword) && hasSpecialChar(userPassword)
}

// testing
let password1 = "Password123!"
let password2 = "password123"

print("Password 1 valid: \(correctPassword(password1))") // prints true
print("Password 2 valid: \(correctPassword(password2))") // prints false

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// * * * * * SECTION C: 1.1 Longest subsequence

// PSEUDO-CODE
/* 1. Create a function findLongestSubSeq that accepts an array unsortedNumbers.
   2. Convert the array into a set to remove duplicates, then sort the set.
   3. Loop through the sorted numbers, and for each number:
    --> Check if the current number is consecutive with the previous number.
        -->If yes: add it to the current sequence.
        --> If no: compare the length of the current sequence with the longest one found so far and update accordingly.
   4. Return both the longest consecutive sequence & its length.

 */
// ! FIND LONGEST CONSEC SEQUENCE FUNCTION
    // --> finds the longest subsequence of consecutive numbers/elements
    // - parameter unsortedNumbers: an array of integers that may contain duplicates and/or be unordered
    // - returns: a tuple of the longest consecutive subsequence and its length

func findLongestSubSeq(_ unsortedNumbers: [Int]) -> ([Int], Int) {
    let sortedUniqueNums = Array(Set(unsortedNumbers)).sorted() // removes duplicates and sorts the array
    
    var longestSeq = [Int]() // variable to store the longest consecutive sequence
    var currentSeq = [Int]() // variable to store the current consecutive sequence
    
    for idx in 0..<sortedUniqueNums.count { // iterate through the sorted array of unique numbers
        
        if idx == 0 || sortedUniqueNums[idx] == sortedUniqueNums[idx - 1] + 1 { // if current number is consecutive -> add it to the current sequence
            currentSeq.append(sortedUniqueNums[idx]) // add the current number to the current sequence
            
        } else {
            if currentSeq.count > longestSeq.count { // compare the current sequence length & the longest sequence
                longestSeq = currentSeq // update the longest sequence
            }
            currentSeq = [sortedUniqueNums[idx]] // begin a new current sequence with the current number
        }
    }
    
    if currentSeq.count > longestSeq.count { // check the last sequence to see if it is the longest
        longestSeq = currentSeq
    }
    
    return (longestSeq, longestSeq.count) // return the longest sequence and its length as a tuple
}

// testing
let exampleArray = [9, 4, 10, 2, 7, 3, 5, 1]
let (longestSubsequence, lengthOfSubsequence) = findLongestSubSeq(exampleArray)

print(longestSubsequence) // prints [1, 2, 3, 4, 5]
print(lengthOfSubsequence) // prints 5

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// * * * * * SECTION D: 1.1 Rock Paper Scissor

// PSEUDO-CODE
/* 1. Create a class RockPaperScissors with 2 properties:
    --> userMove: Stores the user’s choice (rock, paper, or scissors).
    --> computerMove: A randomly generated move selected from "rock", "paper", or "scissors".
   2. Define an initializer that normalizes userMove to lowercase and assigns a random move to computerMove.
   3. Inside the class, create a method gameOutcome:
    --> Compare userMove and computerMove based on the game rules.
    --> Return one of the following strings based on the comparison:
         --> "You Win!" if the user’s move beats the computer's move.
         --> "Computer Wins!" if the computer’s move beats the user’s move.
         --> "It's a Tie!" if both moves are the same.*/

class RockPaperScissors { // class that simulates a rock, paper, scissors game between a user and a computer
    var userMove: String
    var computerMove: String
    
    // ! USER MOVE INITILIZATION
        // --> initializes the game with the user's move and randomly selects the computer's move
        // - parameter userMove: a string representing the user's move ("rock", "paper", or "scissors")
        // - returns: N/A
    
    init(userMove: String) {
        self.userMove = userMove.lowercased() // make user input to lowercase for consistency
        self.computerMove = ["rock", "paper", "scissors"].randomElement()! // randomly assign the computer's move
    }
    
    // ! GAME OUTCOME FUNCTION
        // --> determines the outcome of the Rock, Paper, Scissors game
        // - parameter: N/A
        // - returns:a string indicating whether the user wins, the computer wins, or if it's a tie
    
    func gameOutcome() -> String {
        if userMove == computerMove { // check if it's a tie
            return "It's a tie!" // print tie string
        }
        
        if (userMove == "rock" && computerMove == "scissors") || // rock beats Scissors
           (userMove == "paper" && computerMove == "rock") || // paper beats Rock
           (userMove == "scissors" && computerMove == "paper") { // scissors beat Paper
            return "You Win!" // print winning string (user)
            
        } else {
            return "Computer Wins!" // print winning string (computer)
        }
    }
}

// testing
let userMove = "Rock" // the user's move
let game = RockPaperScissors(userMove: userMove)

print("User Move: \(game.userMove), Computer Move: \(game.computerMove)") // prints what both moves were
print(game.gameOutcome()) // prints one of the two game outcome messages
